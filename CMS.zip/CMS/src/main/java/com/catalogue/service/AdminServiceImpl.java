package com.catalogue.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.catalogue.bean.Admin;
import com.catalogue.bean.Product;
import com.catalogue.dao.IAdminDao;

@Service
public class AdminServiceImpl implements IAdminService{

	@Autowired
	IAdminDao iAdminDao;
	
	@Override
	public String addProductDetails(Product product) {
		return iAdminDao.addProductDetails(product);
	}

	@Override
	public List<Product> deleteProductById(String productId) {
		return iAdminDao.deleteProductById(productId);
	}

	@Override
	public List<Product> searchProduct(String searchTerm) {
		return iAdminDao.searchProduct(searchTerm);
	}

	@Override
	public Admin checkLoginDetails(String userName, String password) {
		return iAdminDao.checkLoginDetails(userName,password);
	}

	@Override
	public List<Product> getAllProducts() {
		return iAdminDao.getAllProducts();
	}

	@Override
	public Boolean addDetails(Admin admin) {
		return iAdminDao.addDetails(admin);
	}

	@Override
	public List<Product> searchProductByRange(double minPrice, double maxPrice) {
		return iAdminDao.searchProductByRange(minPrice,maxPrice);
	}

}
