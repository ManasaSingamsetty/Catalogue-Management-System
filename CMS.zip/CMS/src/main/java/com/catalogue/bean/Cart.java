package com.catalogue.bean;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Cart {
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	private List<ProductInfo> productInfo;
	private Double totalPrice=(double) 0;
	
	public Double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Cart() {
	}
	public List<ProductInfo> getProductInfo() {
		return productInfo;
	}
	public void setProductInfo(List<ProductInfo> productInfo) {
		this.productInfo = productInfo;
	}
	public Cart(List<ProductInfo> productInfo, Double totalPrice) {
		super();
		this.productInfo = productInfo;
		this.totalPrice = totalPrice;
	}
}
