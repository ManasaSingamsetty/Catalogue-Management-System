package com.catalogue.bean;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Customer {
	
	private String customerName;
	@Id
	private String email;
	private String password;
	private Integer securityQuestion;
	private String securityAnswer;
	private Cart cart;
	private OrderInfo orderInfo;
	
	public Customer(Integer customerId, String customerName, String email, String password, Cart cart,
			String country, Integer securityQuestion, String securityAnswer,OrderInfo orderInfo) {
		this.setCustomerName(customerName);
		this.email = email;
		this.password = password;
		this.cart = cart;
		this.securityQuestion = securityQuestion;
		this.securityAnswer = securityAnswer;
		this.orderInfo=orderInfo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Integer getSecurityQuestion() {
		return securityQuestion;
	}
	public void setSecurityQuestion(Integer securityQuestion) {
		this.securityQuestion = securityQuestion;
	}
	public String getSecurityAnswer() {
		return securityAnswer;
	}
	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}
	public Customer() {
	}
	public Cart getCart() {
		return cart;
	}
	public void setCart(Cart cart) {
		this.cart = cart;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public OrderInfo getOrderInfo() {
		return orderInfo;
	}
	public void setOrderInfo(OrderInfo orderInfo) {
		this.orderInfo = orderInfo;
	}
}
