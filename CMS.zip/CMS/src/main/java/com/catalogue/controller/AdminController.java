package com.catalogue.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.catalogue.bean.Admin;
import com.catalogue.bean.Product;
import com.catalogue.service.IAdminService;

@RestController
@RequestMapping("/admin")
//@CrossOrigin(origins = "http://localhost:4200")
public class AdminController {

	@Autowired
	IAdminService iAdminService;
	
	@GetMapping("/login")
	public Admin checkLoginDetails(@RequestParam String userName, String password){
		System.out.println(userName	);
		Admin admin=iAdminService.checkLoginDetails(userName,password);
		if(admin != null)
		{
			return admin;
		}
		return null;
	}
	
	@PostMapping("/register")
	public Boolean registerCustomer(@RequestBody Admin admin) {
		System.out.println("register");
		if(iAdminService.addDetails(admin))
			return true;
		return false;
	}
	
	@GetMapping("/getallproducts")
	public List<Product> getAllProducts(){
		List<Product> productList=iAdminService.getAllProducts();
		if(productList==null) {
			return null;
		}
		return productList;
	}
	
	@PostMapping("/addproduct")
	public List<Product> addProducts(@RequestParam("file") MultipartFile file1) throws IOException{
		String line,name="C:\\Users\\smanasa\\Desktop\\"+file1.getOriginalFilename();
		FileReader fr=new FileReader(name);
		@SuppressWarnings("resource")
		BufferedReader br=new BufferedReader(fr);
	    while((line=br.readLine())!=null) {
	    	Product product=new Product();
	    	String data[]=line.split(",");
	    	product.setProductId(data[0]);
	    	product.setProductName(data[1]);
	    	product.setProductCategory(data[2]);
	    	product.setPrice(data[3]);
	    	product.setUrl(data[4]);
	    	product.setDescription(data[5]);
	    	product.setItemVisibility(data[6]);
	    	product.setQuantity(data[7]);
	    	iAdminService.addProductDetails(product);
	    }
	    List<Product> productList=getAllProducts();
	    if(productList!=null) {
	    	return productList;
	    }
	    return null;
	}
	
	@PostMapping("/addsingleProduct")
	public String addSingleProduct(@RequestBody Product product) {
		if(iAdminService.addProductDetails(product)!=null) {
		return "added";
		}
		return null;
	}
	
	@DeleteMapping("/deleteproduct")
	public List<Product> deleteProduct(@RequestParam String productId){
		List<Product> products=iAdminService.deleteProductById(productId);
		if(products!=null)
			return products;
		return null;
		}
	
	@GetMapping("/searchproduct")
	public List<Product> searchProduct(@RequestParam("searchterm") String searchTerm){
		System.out.println(searchTerm);
		List<Product> productList=iAdminService.searchProduct(searchTerm);
		if(productList!=null) 
		{
			return productList;
		}
		return null;
	}
	
	@GetMapping("/searchproductsbypricerange")
	public List<Product> searchProductsByRange(@RequestParam Double minPrice,Double maxPrice){
		List<Product> productList=iAdminService.searchProductByRange(minPrice,maxPrice);
		if(productList==null) {
			return null;
		}
		return productList;
	}
}
