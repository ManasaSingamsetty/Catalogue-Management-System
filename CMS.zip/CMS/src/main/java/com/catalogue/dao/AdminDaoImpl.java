package com.catalogue.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.catalogue.bean.Admin;
import com.catalogue.bean.Product;

@Repository
public class AdminDaoImpl implements IAdminDao{

	@Autowired
	MongoTemplate mongoTemplate;
	
	@Override
	public String addProductDetails(Product product) {
		if(mongoTemplate.insert(product)!=null) {
			return "added";
		}
		return null;
	}

	@Override
	public List<Product> deleteProductById(String productId) {
		if(mongoTemplate.findById(productId, Product.class) != null) {
			Query query=new Query();
			query.addCriteria(Criteria.where("_id").is(productId));
			mongoTemplate.remove(query,Product.class);
			return getAllProducts();
		}
		return null;
	}

	@Override
	public List<Product> searchProduct(String searchTerm) {
		List<Product> productList = null;
		Query query=new Query();
		query.addCriteria(Criteria.where("productCategory").is(searchTerm));
		productList=mongoTemplate.find(query,Product.class);
		return productList;
	}

	@Override
	public Admin checkLoginDetails(String userName, String password) {
		Query query=new Query();
		query.addCriteria(Criteria.where("userName").is(userName));
		Admin admin=mongoTemplate.findOne(query, Admin.class);
		if(admin != null) {
			if(admin.getPassword().matches(password))
				return admin;
		}
		return null;
	}
	
	@Override
	public List<Product> getAllProducts() {
		List<Product> productList=mongoTemplate.findAll(Product.class);
		return productList;
	}

	@Override
	public Boolean addDetails(Admin admin) {
		Query query=new Query();
		query.addCriteria(Criteria.where("userName").is(admin.getUserName()));
		if(mongoTemplate.findOne(query, Admin.class)==null)
		{
			mongoTemplate.insert(admin);
			return true;
		}
		return false;
	}

	@Override
	public List<Product> searchProductByRange(double minPrice, double maxPrice) {
		List<Product> productList=getAllProducts();
		List<Product> productListSearched=new ArrayList<>();
		for (Product product : productList) {
			if(Double.parseDouble(product.getPrice())>=minPrice&&Double.parseDouble(product.getPrice())<=maxPrice)
			{
				productListSearched.add(product);
			}
		}
		return productListSearched;
	}
}
